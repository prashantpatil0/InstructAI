import 'dart:async';
import 'package:flutter/material.dart';
import 'package:instructai/course_model.dart';
import 'package:flutter/services.dart';
import 'package:flutter_markdown/flutter_markdown.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'package:instructai/quiz_screen.dart';


class CourseDetailScreen extends StatefulWidget {
  final CourseModel course;

  const CourseDetailScreen({super.key, required this.course});

  @override
  State<CourseDetailScreen> createState() => _CourseDetailScreenState();
}

class _CourseDetailScreenState extends State<CourseDetailScreen> {
  final MethodChannel _resetSessionChannel = const MethodChannel(
      'instructai/resetSession');
  final EventChannel _streamChannel = const EventChannel('genai/stream');

  String? selectedModule;
  String userInput = "";
  String generatedLesson = "";

  bool isGenerating = false;
  bool _isPromptInProgress = false;
  bool _inSession = false;

  StreamSubscription? _streamSubscription;

  Future<void> _resetModelSession() async {
    const methodChannel = MethodChannel('genai/method');
    try {
      await methodChannel.invokeMethod('resetSession');
    } catch (e) {
      debugPrint("Error resetting session: $e");
    }
  }

  Future<void> _startSessionGeneration() async {
    if (selectedModule == null || _isPromptInProgress) return;

    if (!mounted) return;

    setState(() {
      generatedLesson = "";
      isGenerating = true;
    });

    await _resetModelSession();
    _isPromptInProgress = true;


    final prompt = """
You are an expert course designer and educator.

Below is the complete course roadmap. From it, find the **"$selectedModule"** section and extract its listed topics.  
You must teach these topics **one by one**, in a clear, focused, and professional manner.

---

###Full Course Roadmap:
${widget.course.roadmap}

---

###Module to Teach:
"$selectedModule"

---

###Student's Focus:
"${userInput.trim().isEmpty ? 'Gain a deep understanding of the module’s topics and master them thoroughly' : userInput.trim()}"

---

###Instructions:
- Identify the topics under "$selectedModule" in the roadmap.
- For **each topic**, write a detailed explanation using proper Markdown.
- Use relevant formatting: `##` for topic titles, bullet points, code blocks, formulas, or visuals if necessary.
- Include **subject-relevant examples** and highlight key ideas or applications.
- Do **not** include introductions, summaries, or generic overviews.
- Focus **strictly on explaining the topics** of this module in sequence.

---

**Style:** Clear, structured, and professional  
**Goal:** Teach each topic as if you're guiding a smart, curious learner.  
**Limit:** ~3000 tokens — be concise but thorough.
""";



    _streamSubscription?.cancel();
    _streamSubscription = _streamChannel
        .receiveBroadcastStream({"prompt": prompt})
        .listen((chunk) {
      if (!mounted) return; // prevent calling setState after dispose
      setState(() {
        generatedLesson += chunk;
      });
    }, onDone: () {
      if (!mounted) return;
      setState(() {
        isGenerating = false;
        _isPromptInProgress = false;
      });
    }, onError: (error) {
      debugPrint("Streaming error: $error");
      if (!mounted) return;
      setState(() {
        isGenerating = false;
        _isPromptInProgress = false;
      });
    });
  }

  Future<void> _downloadAsPdf() async {
    final pdf = pw.Document();

    // Use default built-in Helvetica font
    final font = pw.Font.helvetica();

    pdf.addPage(
      pw.MultiPage(
        pageTheme: pw.PageTheme(
          theme: pw.ThemeData.withFont(base: font),
        ),
        build: (context) {
          // Safely split content into paragraphs or chunks
          final chunks = _splitIntoParagraphs(generatedLesson);

          return [
            pw.Text(
              "Your Session Notes",
              style: pw.TextStyle(fontSize: 24, fontWeight: pw.FontWeight.bold),
            ),
            pw.SizedBox(height: 20),
            // Each chunk becomes a separate Text widget
            ...chunks.map(
                  (chunk) => pw.Padding(
                padding: const pw.EdgeInsets.only(bottom: 10),
                child: pw.Text(
                  chunk,
                  style: pw.TextStyle(fontSize: 14),
                  softWrap: true,
                ),
              ),
            ),
          ];
        },
      ),
    );

    await Printing.layoutPdf(
      onLayout: (format) async => pdf.save(),
    );
  }




  /// Break long text into paragraphs to allow page flow
  List<String> _splitIntoParagraphs(String text) {
    // Splitting on double newlines or long lines if needed
    final lines = text.split('\n\n');
    return lines
        .expand((block) => _splitIfTooLong(block)) // optional: break really long blocks
        .map((e) => e.trim())
        .where((e) => e.isNotEmpty)
        .toList();
  }

  /// Optional: break huge paragraphs
  List<String> _splitIfTooLong(String paragraph, {int maxLength = 1000}) {
    if (paragraph.length <= maxLength) return [paragraph];

    final chunks = <String>[];
    for (int i = 0; i < paragraph.length; i += maxLength) {
      chunks.add(paragraph.substring(i, i + maxLength > paragraph.length ? paragraph.length : i + maxLength));
    }
    return chunks;
  }


  @override
  void dispose() {
    _streamSubscription?.cancel();
    _resetModelSession();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final modules = widget.course.modules.map((m) => m?.title).toList();

    return WillPopScope(
      onWillPop: () async {
        if (isGenerating) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text("Please wait until the lesson is fully generated."),
              duration: Duration(seconds: 2),
              behavior: SnackBarBehavior.floating,
            ),
          );
          return false; // prevent popping
        }
        return true; // allow popping
      },
      child: Scaffold(
        appBar: AppBar(
          title: Text(widget.course.title),
          actions: _inSession
              ? [
            // End session button
            IconButton(
              icon: const Icon(Icons.close),
              tooltip: "End Session",
              onPressed: () {
                if (isGenerating) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text("Please wait until the lesson is fully generated."),
                      duration: Duration(seconds: 2),
                      behavior: SnackBarBehavior.floating,
                    ),
                  );
                } else {
                  setState(() => _inSession = false);
                }
              },
            ),

            // Take Quiz button
            if (!isGenerating && generatedLesson.isNotEmpty)
              IconButton(
                icon: const Icon(Icons.quiz),
                tooltip: "Take Quiz",
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => QuizScreen(
                        selectedModule: selectedModule ?? '',
                        roadmap: widget.course.roadmap ?? '',
                      ),
                    ),
                  );
                },
              ),

          ]
              : null,
        ),

        body: Padding(
          padding: const EdgeInsets.all(12),
          child: _inSession ? _buildSessionView() : _buildPreSession(modules),
        ),
      ),
    );
  }

  Widget _buildPreSession(List<String?> modules) {
    return SingleChildScrollView(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Section: Roadmap
          Card(
            elevation: 3,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    "📋 Course Roadmap",
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 12),
                  MarkdownBody(
                    data: widget.course.roadmap ?? "No roadmap available.",
                    styleSheet: MarkdownStyleSheet.fromTheme(Theme.of(context)).copyWith(
                      p: const TextStyle(fontSize: 16, height: 1.5),
                      h2: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                      h3: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 24),

          // Section: Session Setup
          Card(
            elevation: 3,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Text(
                    "Select Module",
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 12),

                  DropdownButtonFormField<String>(
                    value: selectedModule,
                    isExpanded: true,
                    items: modules.map((m) {
                      return DropdownMenuItem<String>(
                        value: m,
                        child: Text(
                          m!,
                          overflow: TextOverflow.ellipsis,
                        ),
                      );
                    }).toList(),
                    onChanged: (val) => setState(() => selectedModule = val),
                    decoration: const InputDecoration(
                      border: OutlineInputBorder(),
                      hintText: "Choose a module",
                    ),
                  ),

                  const SizedBox(height: 20),

                  const Text(
                    "Focus Area (Optional)",
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 10),

                  TextField(
                    onChanged: (val) => userInput = val,
                    maxLines: 2,
                    decoration: const InputDecoration(
                      hintText: "E.g. beginner-friendly, with code examples",
                      border: OutlineInputBorder(),
                    ),
                  ),

                  const SizedBox(height: 24),

                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton.icon(
                      icon: const Icon(Icons.play_arrow, color: Colors.white),
                      label: const Text(
                        "Start Learning Session",
                        style: TextStyle(color: Colors.white),
                      ),
                      onPressed: selectedModule == null
                          ? null
                          : () {
                        setState(() {
                          _inSession = true;
                        });
                        _startSessionGeneration();
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: selectedModule == null ? Colors.grey : Colors.deepPurple,
                        padding: const EdgeInsets.symmetric(vertical: 16),
                        textStyle: const TextStyle(fontSize: 16),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                        foregroundColor: Colors.white,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          )

        ],
      ),
    );
  }


  Widget _buildSessionView() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          "$selectedModule",
          style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 12),

        if (isGenerating)
          const LinearProgressIndicator(),
        if (isGenerating)
          const SizedBox(height: 16),

        Expanded(
          child: generatedLesson.isEmpty
              ? const Center(
            child: Text(
              "Generating session content...",
              style: TextStyle(fontSize: 16),
            ),
          )
              : Container(
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(14),
              boxShadow: [
                BoxShadow(
                  color: Colors.grey.shade300,
                  blurRadius: 6,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
            padding: const EdgeInsets.all(16),
            child: Markdown(
              data: generatedLesson,
              selectable: true,
              styleSheet: MarkdownStyleSheet.fromTheme(Theme.of(context)).copyWith(
                p: const TextStyle(fontSize: 16, height: 1.5),
                code: const TextStyle(
                  backgroundColor: Color(0xFFF6F8FA),
                  fontFamily: 'monospace',
                  fontSize: 14,
                ),
                h2: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                h3: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
            ),
          ),
        ),
        const SizedBox(height: 20),

        if (!isGenerating)
          Row(
            children: [
              Expanded(
                child: ElevatedButton.icon(
                  onPressed: _startSessionGeneration,
                  icon: const Icon(Icons.refresh, color: Colors.white),
                  label: const Text(
                    "Regenerate",
                    style: TextStyle(color: Colors.white),
                  ),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.deepPurple,
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: ElevatedButton.icon(
                  onPressed: _downloadAsPdf,
                  icon: const Icon(Icons.download, color: Colors.white),
                  label: const Text(
                    "Download PDF",
                    style: TextStyle(color: Colors.white),
                  ),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.deepPurple,
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                ),
              ),
            ],
          ),
      ],
    );
  }

}