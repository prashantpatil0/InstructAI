import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:path_provider/path_provider.dart';
import 'main.dart';

class DownloadModelScreen extends StatefulWidget {
  const DownloadModelScreen({super.key});

  @override
  State<DownloadModelScreen> createState() => _DownloadModelScreenState();
}

class _DownloadModelScreenState extends State<DownloadModelScreen> {
  final String modelFileName = "gemma-3n-E2B-it-int4.task";
  final String downloadUrl = "https://huggingface.co/gummybear2555/Gemma-3n-E2B-it-int4/blob/main/gemma-3n-E2B-it-int4.task";
  String modelFolderPath = "";

  @override
  void initState() {
    super.initState();
    _prepareModelFolder();
  }

  Future<void> _prepareModelFolder() async {
    final Directory baseDir = Directory('/storage/emulated/0/InstructAI/models');

    if (!await baseDir.exists()) {
      await baseDir.create(recursive: true);
    }

    setState(() {
      modelFolderPath = baseDir.path;
    });
  }
  Future<void> _copyToClipboard() async {
    await Clipboard.setData(ClipboardData(text: downloadUrl));
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text("Link copied to clipboard")),
    );
  }

  Future<void> _onContinuePressed() async {
    final modelFile = File("$modelFolderPath/$modelFileName");

    if (await modelFile.exists()) {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (_) => const MainNavigationScreen()),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Model file not found in InstructAI/models folder.")),
      );
    }
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("AI Model Setup")),
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: modelFolderPath.isEmpty
            ? const Center(child: CircularProgressIndicator())
            : SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                "To run the AI features offline, you need to download a model file manually.\n\n"
                    "Just follow these quick steps:",
                style: TextStyle(fontSize: 16),
              ),
              const SizedBox(height: 24),

              /// STEP 1
              const Text(
                "📥 Step 1: Copy the download link below",
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
              ),
              const SizedBox(height: 8),
              GestureDetector(
                onTap: _copyToClipboard,
                child: Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: Colors.grey[200],
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Row(
                    children: const [
                      Expanded(
                        child: Text(
                          "https://huggingface.co/.../gemma-3n-E2B-it-int4.task",
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(fontFamily: 'monospace'),
                        ),
                      ),
                      Icon(Icons.copy, size: 18)
                    ],
                  ),
                ),
              ),

              const SizedBox(height: 20),

              /// STEP 2
              const Text(
                "🌐 Step 2: Open this link in your browser and download the file.",
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
              ),
              const SizedBox(height: 20),

              /// STEP 3
              const Text(
                "📂 Step 3: Move the downloaded `.task` file to this folder:",
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
              ),
              const SizedBox(height: 8),
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.grey.shade100,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: SelectableText(
                  modelFolderPath,
                  style: const TextStyle(
                    fontWeight: FontWeight.w500,
                    color: Colors.blueGrey,
                    fontFamily: 'monospace',
                  ),
                ),
              ),

              const SizedBox(height: 32),

              /// CONTINUE BUTTON
              SizedBox(
                width: double.infinity,
                child: ElevatedButton.icon(
                  onPressed: _onContinuePressed,
                  icon: const Icon(Icons.check_circle),
                  label: const Text("Continue (Model is placed)"),
                  style: ElevatedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 16),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

}
