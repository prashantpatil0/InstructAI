import 'package:flutter/material.dart';
import 'package:instructai/recommended_course_detail_screen.dart';
import 'course_data.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  late List<String> categories;
  String selectedCategory = "All";

  @override
  void initState() {
    super.initState();
    categories = [
      "All",
      ...{...recommendedCourses.map((c) => c['category'] as String)}
    ];
  }

  @override
  Widget build(BuildContext context) {
    final filteredCourses = selectedCategory == "All"
        ? recommendedCourses
        : recommendedCourses
        .where((course) => course['category'] == selectedCategory)
        .toList();

    return Scaffold(
      appBar: AppBar(
        title: const Text("InstructAI Courses"),
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildCategoryChips(),
          const SizedBox(height: 8),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12.0),
              child: LayoutBuilder(
                builder: (context, constraints) {
                  return GridView.builder(
                    itemCount: filteredCourses.length,
                    gridDelegate: SliverGridDelegateWithMaxCrossAxisExtent(
                      maxCrossAxisExtent: 350,
                      mainAxisSpacing: 14,
                      crossAxisSpacing: 14,
                      childAspectRatio: 0.76,
                    ),
                    itemBuilder: (context, index) {
                      final course = filteredCourses[index];
                      return _buildCourseCard(
                        context,
                        course["title"],
                        course["description"],
                        List<String>.from(course["skills"]),
                        course["outcomes"],
                      );
                    },
                  );
                },
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCategoryChips() {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 3),
      child: Row(
        children: categories
            .map((cat) => Padding(
          padding: const EdgeInsets.only(right: 5),
          child: ChoiceChip(
            label: Text(cat),
            selected: selectedCategory == cat,
            onSelected: (_) {
              setState(() {
                selectedCategory = cat;
              });
            },
            selectedColor: Colors.deepPurple,
            backgroundColor: Colors.grey.shade200,
            labelStyle: TextStyle(
              color: selectedCategory == cat
                  ? Colors.white
                  : Colors.black87,
              fontWeight: FontWeight.w500,
            ),
          ),
        ))
            .toList(),
      ),
    );
  }


  Widget _buildCourseCard(
      BuildContext context,
      String title,
      String description,
      List<String> skills,
      String outcomes,
      ) {
    return GestureDetector(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => RecommendedCourseDetailScreen(
              title: title,
              description: description,
            ),
          ),
        );
      },
      child: Card(
        elevation: 4,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        child: Padding(
          padding: const EdgeInsets.all(12.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              /// Title
              Text(
                title,
                style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: Colors.black87),
              ),

              const SizedBox(height: 6),

              /// Description in an outlined box
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  border: Border.all(color: Colors.grey.shade300),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(
                  description,
                  maxLines: 3,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontSize: 13.2, color: Colors.black87),
                ),
              ),

              const SizedBox(height: 10),

              /// Skills Header
              const Text(
                "Skills you’ll gain:",
                style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600),
              ),

              const SizedBox(height: 6),

              /// Skill Chips
              Wrap(
                spacing: 6,
                runSpacing: 4,
                children: skills
                    .map(
                      (skill) => Chip(
                    label: Text(skill, style: const TextStyle(fontSize: 11)),
                    backgroundColor: Colors.deepPurple.shade50,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8)),
                    padding: const EdgeInsets.symmetric(
                        horizontal: 8, vertical: 0),
                  ),
                )
                    .toList(),
              ),

              const SizedBox(height: 10),

              /// Outcome Header
              const Text(
                "Course Outcome:",
                style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600),
              ),

              const SizedBox(height: 4),

              /// Outcome Text
              Text(
                outcomes,
                style: const TextStyle(fontSize: 12.3, color: Colors.black87),
                maxLines: 3,
                overflow: TextOverflow.ellipsis,
              ),

              const Spacer(),

              /// Button
              SizedBox(
                width: double.infinity,
                child: ElevatedButton.icon(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => RecommendedCourseDetailScreen(
                          title: title,
                          description: description,
                        ),
                      ),
                    );
                  },
                  icon: const Icon(Icons.map, size: 16),
                  label: const Text("View Roadmap",
                      style: TextStyle(fontSize: 13)),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.deepPurple.shade600,
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(vertical: 8),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                    elevation: 2,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

}
