import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class QuizScreen extends StatefulWidget {
  final String selectedModule;
  final String roadmap;

  const QuizScreen({
    super.key,
    required this.selectedModule,
    required this.roadmap,
  });

  @override
  State<QuizScreen> createState() => _QuizScreenState();
}

class _QuizScreenState extends State<QuizScreen> {
  static const MethodChannel _methodChannel = MethodChannel('genai/method');
  static const EventChannel _streamChannel = EventChannel('genai/stream');

  late StreamSubscription _streamSubscription;

  List<dynamic> _questions = [];
  String _buffer = "";
  bool _isLoading = false;
  bool _hasError = false;

  // Track selected answers and whether user answered
  final Map<int, String> _selectedAnswers = {};
  final Map<int, bool> _answered = {};

  @override
  void initState() {
    super.initState();
    _generateQuiz();
  }

  @override
  void dispose() {
    _streamSubscription.cancel();
    _resetModelSession();
    super.dispose();
  }

  Future<void> _resetModelSession() async {
    try {
      await _methodChannel.invokeMethod("resetSession");
    } catch (e) {
      debugPrint("Reset session failed: $e");
    }
  }

  Future<void> _generateQuiz() async {
    await _resetModelSession(); // Clear old context

    setState(() {
      _buffer = "";
      _isLoading = true;
      _hasError = false;
    });

    final prompt = """
You are an AI tutor. Based on the roadmap and selected module, generate 5 quiz questions in this JSON format:

[
  {
    "type": "mcq",
    "question": "What does HTTP stand for?",
    "options": ["Option A", "Option B", "Option C", "Option D"],
    "answer": "Option A"
  },
  {
    "type": "true_false",
    "question": "HTML is a programming language.",
    "answer": "False"
  }
]

Only return valid JSON. Use only the selected module to create questions.

Selected Module: ${widget.selectedModule}
Roadmap: ${widget.roadmap}
""";

    try {
      _streamSubscription = _streamChannel
          .receiveBroadcastStream({"prompt": prompt})
          .listen((data) {
        setState(() {
          _buffer += data;
        });
      }, onDone: () {
        try {
          final start = _buffer.indexOf('[');
          final end = _buffer.lastIndexOf(']');
          final jsonStr = _buffer.substring(start, end + 1);
          final List<dynamic> result = json.decode(jsonStr);
          setState(() {
            _questions.addAll(result);
            _isLoading = false;
          });
        } catch (e) {
          setState(() {
            _hasError = true;
            _isLoading = false;
          });
        }
      }, onError: (e) {
        setState(() {
          _hasError = true;
          _isLoading = false;
        });
      });
    } catch (e) {
      setState(() {
        _hasError = true;
        _isLoading = false;
      });
    }
  }

  void _submitAnswer(int index, String selected) {
    setState(() {
      _selectedAnswers[index] = selected;
      _answered[index] = true;
    });
  }

  Widget _buildQuestion(Map<String, dynamic> q, int i) {
    final type = q['type'];
    final question = q['question'];
    final correctAnswer = q['answer'];
    final options = (q['options'] as List?) ??
        (type == 'true_false' ? ['True', 'False'] : []);

    final hasAnswered = _answered[i] == true;
    final selectedAnswer = _selectedAnswers[i];

    return Card(
      margin: const EdgeInsets.symmetric(vertical: 10, horizontal: 16),
      elevation: 3,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text("Q${i + 1}. $question",
                style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
            const SizedBox(height: 10),

            ...options.map((opt) {
              final isSelected = selectedAnswer == opt;
              final isCorrect = opt == correctAnswer;

              Color? tileColor;
              if (hasAnswered) {
                if (isSelected && isCorrect) {
                  tileColor = Colors.green[100];
                } else if (isSelected && !isCorrect) {
                  tileColor = Colors.red[100];
                } else if (isCorrect) {
                  tileColor = Colors.green[50];
                }
              }

              return Container(
                margin: const EdgeInsets.only(bottom: 6),
                decoration: BoxDecoration(
                  color: tileColor,
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: Colors.grey.shade300),
                ),
                child: ListTile(
                  title: Text(opt),
                  leading: Radio<String>(
                    value: opt,
                    groupValue: selectedAnswer,
                    onChanged: hasAnswered ? null : (val) => _submitAnswer(i, val!),
                  ),
                  onTap: hasAnswered ? null : () => _submitAnswer(i, opt),
                ),
              );
            }),

            if (hasAnswered) ...[
              const SizedBox(height: 6),
              Text(
                selectedAnswer == correctAnswer
                    ? "✅ Correct!"
                    : "❌ Incorrect. Correct answer: $correctAnswer",
                style: TextStyle(
                  color: selectedAnswer == correctAnswer ? Colors.green : Colors.red,
                  fontWeight: FontWeight.bold,
                ),
              )
            ]
          ],
        ),
      ),
    );
  }

  Widget _buildQuizUI() {
    if (_isLoading) {
      return const Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CircularProgressIndicator(),
            SizedBox(height: 16),
            Text(
              "Generating quiz... Please wait",
              style: TextStyle(fontSize: 16),
            ),
          ],
        ),
      );
    }

    if (_hasError) {
      return Center(
        child: Column(
          children: [
            const Text("Failed to generate quiz."),
            ElevatedButton(onPressed: _generateQuiz, child: const Text("Retry")),
          ],
        ),
      );
    }

    return Column(
      children: [
        Expanded(
          child: ListView.builder(
            itemCount: _questions.length,
            itemBuilder: (_, i) => _buildQuestion(_questions[i], i),
          ),
        ),
        Padding(
          padding: const EdgeInsets.all(16),
          child: Row(
            children: [
              Expanded(
                child: OutlinedButton(
                  onPressed: _generateQuiz,
                  child: const Text("➕ Generate 5 More"),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: ElevatedButton(
                  onPressed: _isLoading ? null : () => Navigator.pop(context),
                  child: const Text("Exit"),
                ),
              )
            ],
          ),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async => !_isLoading,
      child: Scaffold(
        appBar: AppBar(title: const Text("Quiz Time")),
        body: _buildQuizUI(),
      ),
    );
  }
}