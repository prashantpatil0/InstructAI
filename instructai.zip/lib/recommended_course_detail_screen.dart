import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_markdown/flutter_markdown.dart';
import 'package:hive/hive.dart';
import 'package:uuid/uuid.dart';
import 'course_model.dart';
import 'learn_screen.dart';

class RecommendedCourseDetailScreen extends StatefulWidget {
  final String title;
  final String description;

  const RecommendedCourseDetailScreen({
    super.key,
    required this.title,
    required this.description,
  });

  @override
  State<RecommendedCourseDetailScreen> createState() =>
      _RecommendedCourseDetailScreenState();
}

class _RecommendedCourseDetailScreenState extends State<RecommendedCourseDetailScreen> {
  static const EventChannel _streamChannel = EventChannel('genai/stream');
  static const MethodChannel _methodChannel = MethodChannel('genai/method');

  String roadmapText = "";
  StreamSubscription? _streamSubscription;

  bool _isGenerating = false;
  bool _isModelBusy = false;

  @override
  void initState() {
    super.initState();
    _generateRoadmap();
  }

  Future<void> _generateRoadmap() async {
    if (_isModelBusy) {
      _showModelBusyWarning();
      return;
    }

    await _resetModelSession();

    setState(() {
      roadmapText = "";
      _isGenerating = true;
      _isModelBusy = true;
    });

    await _streamSubscription?.cancel();

    _streamSubscription = _streamChannel
        .receiveBroadcastStream({
      "prompt": _buildPrompt(widget.title, widget.description),
    })
        .listen(
          (chunk) {
        if (!mounted) return;
        setState(() {
          roadmapText += chunk;
        });
      },
      onDone: () {
        if (!mounted) return;
        setState(() {
          _isGenerating = false;
          _isModelBusy = false;
        });
      },
      onError: (error) {
        if (!mounted) return;
        setState(() {
          _isGenerating = false;
          _isModelBusy = false;
        });
      },
    );
  }

  Future<void> _resetModelSession() async {
    try {
      await _methodChannel.invokeMethod('cancelGeneration');
    } catch (e) {
      debugPrint("Model reset failed: $e");
    }
  }

  void _showModelBusyWarning() {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text("⏳ Please wait for the current roadmap to finish before starting a new one."),
        duration: Duration(seconds: 3),
      ),
    );
  }

  String _buildPrompt(String title, String desc) {
    return '''
You are an expert AI course creator. Based on the following course, generate a structured roadmap that progressively covers all important concepts from beginner to advanced level.

Course Title: "$title"  
Course Description: $desc

Instructions:
- Structure the roadmap into **up to 3 modules**:
  - **Module 1** should focus on **Beginner** level fundamentals.
  - **Module 2** should cover **Intermediate** topics that build upon the basics.
  - **Module 3** (if needed) should introduce **Advanced** concepts or applications.
- Each module must include:
  - A **descriptive title**
  - **3 to 4 concise and logically grouped topics** that represent the scope of that level.
- Ensure the course covers **all essential and practical concepts** needed to understand or apply the subject thoroughly.
- Be informative yet compact. Avoid repetition.
- Add an **Estimated Completion Time** at the end, based on the topic depth.

Output Format:

Module 1 (Beginner): [Module Title]
- Topic 1
- Topic 2
- Topic 3

Module 2 (Intermediate): [Module Title]
- Topic 1
- Topic 2
- Topic 3

Module 3 (Advanced): [Module Title]
- Topic 1
- Topic 2
- Topic 3

Estimated Completion Time: [X hours] or [X weeks]
''';
  }

  void _saveAndStartLearning() async {
    final parsedModules = _parseRoadmap(roadmapText);
    if (parsedModules.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Invalid roadmap. Try regenerating.")),
      );
      return;
    }

    final box = await Hive.openBox<CourseModel>('courses');
    final course = CourseModel(
      id: const Uuid().v4(),
      title: widget.title,
      description: widget.description,
      modules: parsedModules,
      isRecommended: true,
      roadmap: roadmapText,
      isStarted: true,
      createdAt: DateTime.now(),
    );
    await box.put(course.id, course);

    if (!mounted) return;

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text("🎉 Course Added"),
        content: const Text("You can now start learning this course from the Learn tab."),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(context).pop(); // dialog
              Navigator.of(context).pop(); // screen
            },
            child: const Text("OK"),
          ),
        ],
      ),
    );
  }

  List<ModuleModel> _parseRoadmap(String roadmap) {
    final lines = roadmap.split('\n');
    final modules = <ModuleModel>[];

    String? currentTitle;
    List<String> currentTopics = [];

    final moduleRegex = RegExp(r'^\*\*(.+?)\*\*$');

    for (var line in lines) {
      final trimmed = line.trim();
      if (trimmed.isEmpty || trimmed.toLowerCase().startsWith('estimated')) continue;

      final match = moduleRegex.firstMatch(trimmed);
      if (match != null) {
        if (currentTitle != null && currentTopics.isNotEmpty) {
          modules.add(ModuleModel(title: currentTitle, topics: List.from(currentTopics)));
        }
        currentTitle = match.group(1)?.trim();
        currentTopics.clear();
      } else if (trimmed.startsWith('-')) {
        currentTopics.add(trimmed.substring(1).trim());
      }
    }

    if (currentTitle != null && currentTopics.isNotEmpty) {
      modules.add(ModuleModel(title: currentTitle, topics: currentTopics));
    }

    return modules;
  }

  @override
  void dispose() {
    _streamSubscription?.cancel();
    _resetModelSession();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        if (_isModelBusy) {
          _showModelBusyWarning();
          return false;
        }
        return true;
      },
      child: Scaffold(
        appBar: AppBar(title: Text(widget.title)),
        body: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(widget.description,
                  style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w400)),
              const SizedBox(height: 20),
              Expanded(
                child: Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    border: Border.all(color: Colors.deepPurple.shade100),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: roadmapText.isEmpty
                      ? Center(
                    child: Text(
                      _isGenerating
                          ? "⏳ Generating roadmap..."
                          : "No roadmap generated yet.",
                      style: const TextStyle(fontSize: 16),
                    ),
                  )
                      : SingleChildScrollView(
                    child: MarkdownBody(
                      data: roadmapText,
                      selectable: true,
                      styleSheet:
                      MarkdownStyleSheet.fromTheme(Theme.of(context)).copyWith(
                        p: const TextStyle(fontSize: 15, height: 1.5),
                        listBullet: const TextStyle(fontSize: 15),
                        code: const TextStyle(
                          fontSize: 13,
                          backgroundColor: Color(0xFFF0F0F0),
                          fontFamily: 'monospace',
                        ),
                        h2: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                        h3: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                      ),
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 20),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: _isGenerating ? null : _generateRoadmap,
                      icon: const Icon(Icons.refresh),
                      label: const Text("Regenerate"),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: ElevatedButton.icon(
                      onPressed: _isGenerating ? null : _saveAndStartLearning,
                      icon: const Icon(Icons.play_arrow),
                      label: const Text("Start Learning"),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
