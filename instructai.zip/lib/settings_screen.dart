import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  void _launchURL(String url) async {
    final uri = Uri.parse(url);
    if (await canLaunchUrl(uri)) {
      launchUrl(uri);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('About InstructAI'),
        centerTitle: true,
        elevation: 1,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const CircleAvatar(
              radius: 40,
              backgroundImage: AssetImage('assets/icon.png'), // Add app icon
            ),
            const SizedBox(height: 16),
            const Text(
              'InstructAI',
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            const Text(
              'Your offline AI tutor — powered by Gemma',
              style: TextStyle(fontSize: 16, color: Colors.grey),
            ),
            const SizedBox(height: 24),

            _buildSectionTitle('🚀 Mission'),
            const Text(
              'To make high-quality, personalized learning accessible — even offline — using on-device AI.',
              style: TextStyle(fontSize: 16),
            ),
            const SizedBox(height: 20),

            _buildSectionTitle('✨ Features'),
            const _BulletItem(text: '📚 AI-generated course roadmaps'),
            const _BulletItem(text: '🧠 Topic-wise lessons with real-time streaming'),
            const _BulletItem(text: '📥 Offline learning powered by Gemma'),
            const _BulletItem(text: '🗂 Save & resume progress anytime'),
            const SizedBox(height: 20),

            _buildSectionTitle('⚙️ Tech Stack'),
            const _BulletItem(text: 'Flutter + Dart'),
            const _BulletItem(text: 'MediaPipe Tasks (Gemma 3n)'),
            const _BulletItem(text: 'Local Hive DB for course storage'),
            const SizedBox(height: 20),

            _buildSectionTitle('Developed By'),
            const Text(
              'Prashant Patil',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.w500),
            ),
            const SizedBox(height: 8),
            GestureDetector(
              onTap: () => _launchURL('mailto:patilprashant9307@gmail.com'),
              child: const Text(
                'patilprashant9307@gmail.com',
                style: TextStyle(
                  color: Colors.blue,
                  decoration: TextDecoration.underline,
                ),
              ),
            ),
            const SizedBox(height: 20),

            _buildSectionTitle('Version'),
            const Text('v1.0.0'),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  Widget _buildSectionTitle(String title) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Text(
        title,
        style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
      ),
    );
  }
}

class _BulletItem extends StatelessWidget {
  final String text;
  const _BulletItem({required this.text});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(left: 6, bottom: 6),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text("• ", style: TextStyle(fontSize: 18)),
          Expanded(child: Text(text, style: const TextStyle(fontSize: 16))),
        ],
      ),
    );
  }
}
