import 'dart:io';
import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'download_model_screen.dart';
import 'main.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  final String modelFileName = "gemma-3n-E2B-it-int4.task";

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    try {
      final permissionGranted = await _requestStoragePermission();

      if (!permissionGranted) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text("Storage permission is required to continue")),
          );
        }
        return;
      }

      // Add slightly more delay to ensure system is stable after permission grant
      await Future.delayed(const Duration(milliseconds: 800));

      final modelExists = await _checkModelFileExists();

      if (!mounted) return;

      if (modelExists) {
        _goToMainApp();
      } else {
        _goToDownloadScreen();
      }
    } catch (e, stack) {
      debugPrint("Splash init error: $e\n$stack");
      if (mounted) _goToDownloadScreen(); // fallback
    }
  }

  Future<bool> _checkModelFileExists() async {
    try {
      const modelFolderPath = "/storage/emulated/0/InstructAI/models";
      final modelPath = "$modelFolderPath/$modelFileName";
      return File(modelPath).existsSync(); // use sync inside async for safety
    } catch (_) {
      return false;
    }
  }
  Future<bool> _requestStoragePermission() async {
    if (Platform.isAndroid) {
      final deviceInfo = DeviceInfoPlugin();
      final androidInfo = await deviceInfo.androidInfo;
      final sdkInt = androidInfo.version.sdkInt;

      if (sdkInt >= 30) {
        final status = await Permission.manageExternalStorage.status;
        if (status.isGranted) return true;

        final result = await Permission.manageExternalStorage.request();
        return result.isGranted;
      } else {
        final status = await Permission.storage.status;
        if (status.isGranted) return true;

        final result = await Permission.storage.request();
        return result.isGranted;
      }
    }
    return true; // Non-Android platforms
  }

  void _goToMainApp() {
    if (!mounted) return;
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (_) => const MainNavigationScreen()),
    );
  }

  void _goToDownloadScreen() {
    if (!mounted) return;
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (_) => const DownloadModelScreen()),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white, // or your app’s primary color
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // App Icon (replace with your logo if needed)
            Icon(
              Icons.school,
              size: 64,
              color: Colors.deepPurple,
            ),

            const SizedBox(height: 16),

            // App Name
            const Text(
              "InstructAI",
              style: TextStyle(
                fontSize: 28,
                fontWeight: FontWeight.bold,
                color: Colors.black87,
              ),
            ),

            const SizedBox(height: 12),

            // Subtext or Loading Message
            const Text(
              "Preparing your experience...",
              style: TextStyle(
                fontSize: 16,
                color: Colors.grey,
              ),
            ),
          ],
        ),
      ),
    );
  }

}
